# beamer_template
Attempt at a Beamer Template for CSAFE
